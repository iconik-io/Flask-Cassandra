# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flask_cassandra']

package_data = \
{'': ['*']}

install_requires = \
['Flask>=2.3.2,<3.0.0', 'cassandra-driver>=3.27.0,<4.0.0']

setup_kwargs = {
    'name': 'flask-cassandra',
    'version': '0.1.4',
    'description': '',
    'long_description': None,
    'author': 'Konstantin Hantsov',
    'author_email': 'hantsov@iconik.io',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
